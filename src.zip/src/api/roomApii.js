import axios from 'axios';

// Use API Gateway URL
const BASE_URL = 'http://localhost:8085/api';
// localStorage.setItem('isLoggedIn',true);

export const getAllRooms = () => axios.get(`${BASE_URL}/listRooms`, { withCredentials: true });

export const getAllEmployees = () => axios.get(`${BASE_URL}/listEmployees`, { withCredentials: true });

export const updateEmployeeRoom = (empId, newRoomId) =>
  axios.put(`${BASE_URL}/updateEmployee/${empId}/${newRoomId}`, {}, { withCredentials: true });



