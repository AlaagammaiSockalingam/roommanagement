import React from 'react';
import { useNavigate } from 'react-router-dom';
import './landingPage.css';
 
const LandingPage = () => {
  const navigate = useNavigate();
 
  const handleStart = () => {
    navigate('/login');
  };
 
  return (
    <div className="landing-container">
      <div className="overlay" />
      <div className="landing-content">
        <h1 className="title">Room Management System</h1>
        <p className="subtitle">
          Streamline your room operations with our all-in-one platform.
        </p>
 
        <div className="modules">
          <div className="module-card">
            <h3>Room Booking <br></br>Management</h3>
            <p>Role: TeamLead</p>
            <p>Team Lead manages the conference room management</p>
          </div>
          <div className="module-card">
            <h3>Room Maintenance Management</h3>
            <p>Role: Maintenance Head</p>
            <p>Maintenance Head manage maintenance of the room.</p>
          </div>
          <div className="module-card">
            <h3>Employee Management and Room allocation</h3>
            <p>Role: Management Head</p>
            <p>Management Head manage room allocation of the Employees</p>
          </div>
        </div>
 
        <button className="start-button" onClick={handleStart}>
          Get Started
        </button>
      </div>
    </div>
  );
};
 
export default LandingPage;