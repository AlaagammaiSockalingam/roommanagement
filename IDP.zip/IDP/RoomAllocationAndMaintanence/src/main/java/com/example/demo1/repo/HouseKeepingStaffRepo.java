package com.example.demo1.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo1.entiries.HousekeepingStaff;

public interface HouseKeepingStaffRepo extends JpaRepository<HousekeepingStaff, Long>{

}
