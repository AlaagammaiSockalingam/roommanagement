package com.example.demo1.dto;

public class RoomIdDto {
	
	private int roomId;
 
	public int getRoomId() {
		return roomId;
	}
 
	public void setRoomId(int roomId) {
		this.roomId = roomId;
	}
 
	public RoomIdDto(int roomId) {
		super();
		this.roomId = roomId;
	}
 
	public RoomIdDto() {
		
	}
	
	
 
}
 