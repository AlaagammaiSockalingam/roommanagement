package com.cts.room_booking.controller;
 
 
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
 
import com.cts.room_booking.dto.BookingRequest;
import com.cts.room_booking.dto.UpdateAvailabilityRequest;
import com.cts.room_booking.entities.Booking;
import com.cts.room_booking.entities.ConferenceRoom;
import com.cts.room_booking.service.RoomService;
 
import java.util.List;
import java.util.Map;
 
@RestController
@CrossOrigin(origins = "http://localhost:3000")
@RequestMapping("/roombooking")
public class RoomController {
 
    @Autowired
    private RoomService roomService;
 
    /**
     * Get available conference rooms.
     */
//    @GetMapping("hello")
//    public String hello() {
//    	return "hello";
//    }
    @GetMapping("/available/{requiredSeats}")
    public List<?> getConferenceRooms(@PathVariable int requiredSeats) {
        return roomService.getAvailableConferenceRooms(requiredSeats);
    }
 
    /**
     * Book a conference room.
     */
    @PostMapping("/book/{roomId}")
    public String bookConferenceRoom(@PathVariable Long roomId, @RequestBody BookingRequest bookingRequest) {
        return roomService.bookConferenceRoom(
                roomId,
                bookingRequest.getRequiredSeats(),
                bookingRequest.getStartTime(),
                bookingRequest.getEndTime(),
                bookingRequest.getEmpId()
        );
    }
 
    /**
     * Update room availability manually.
     */
    @PutMapping("/update-availability")
    public String updateRoomAvailability(@RequestBody UpdateAvailabilityRequest request) {
        roomService.updateRoomAvailability(request.getRoomId(), request.getAvailability());
        return "Room availability updated to " + request.getAvailability();
    }
 
    /**
     * Add a conference room.
     */
    @PostMapping("/add")
    public String addConferenceRoom(@RequestBody ConferenceRoom room) {
        return roomService.addConferenceRoom(room);
    }
    @GetMapping("/listConferenceRoom")
    public List<ConferenceRoom> hello() {
    	return roomService.conferenceRoomList();
    }
    @DeleteMapping("/cancel/{bookingId}")
    public ResponseEntity<String> cancelBooking(@PathVariable Long bookingId) {
        String response = roomService.cancelBooking(bookingId);
        return ResponseEntity.ok(response);
    }
//    @GetMapping("/bookings/{empId}")
//    public List<Booking> getBookingsByEmployee(@PathVariable Long empId) {
//        List<Booking> bookings = roomService.getBookingsByEmployee(empId);
//
//        // Ensure conferenceRoom data is included in each booking response
//        for (Booking booking : bookings) {
//            booking.setConferenceRoom(
//                roomService.getConferenceRoomById(booking.getConferenceRoom().getId())
//            );
//        }
//
//        return bookings;
//    }
//    @GetMapping("/bookings/{empId}")
//    public List<Booking> getBookingsByEmployee(@PathVariable Long empId) {
//        return roomService.getBookingsByEmployee(empId); // No need to manually set conferenceRoom anymore
//    }
//    
//    @GetMapping("/bookings/{empId}")
//    public List<Booking> getBookingsByEmployee(@PathVariable Long empId) {
//        List<Booking> bookings = roomService.getBookingsByEmployee(empId);
//
//        // Debugging: Print room name in logs
//        bookings.forEach(booking -> {
//            System.out.println("Booking ID: " + booking.getId());
//            System.out.println("Conference Room Data: " + booking.getConferenceRoom());
//        });
//
//        return bookings;
//    }
  //  @GetMapping("/bookings/{empId}")
   // public List<Booking> getBookingsByEmployee(@PathVariable Long empId) {
      //  List<Booking> bookings = roomService.getBookingsByEmployee(empId);
 
        // Debugging: Print full response in logs
       // bookings.forEach(booking -> {
       //     System.out.println("Booking ID: " + booking.getId());
        //    System.out.println("Conference Room Data: " + booking.getConferenceRoom());
      //  });
 
     //   return bookings;
   // }
    @GetMapping("/rooms-booked/{empId}")
    public List<Map<String, Object>> getRoomsByEmployee(@PathVariable Long empId) {
        return roomService.getRoomsBookedByEmployee(empId);
    }
 
 
 
 
}